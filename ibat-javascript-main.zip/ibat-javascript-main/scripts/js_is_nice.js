function jsIsNice() {
    alert("Javascript is nice!");
  }